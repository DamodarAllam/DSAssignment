package com.damodar;

import java.util.Scanner;

public class User_validationApplication {
	
public static void main(String[] args) {
	
	Scanner sc=new Scanner(System.in);
	for(int i=0;i<=3;i++) {
		if(i==3 || i>3) {
			System.out.println("[  Contact to Admin .............]");
			break;
		}
		System.out.println("Enter User Name :");
		String username=sc.next();
		System.out.println("Enter Password :");
		String pass=sc.next();
		if(username.equals("damodar2510") && pass.equals("56789")) {
			
			System.out.println("Welcome "+username);
			break;
		}else {
			
			System.out.println("Invalid UserID or Password");
			System.out.println("Remaining attempt is "+(2-i));
		}
		
	}
}
}
